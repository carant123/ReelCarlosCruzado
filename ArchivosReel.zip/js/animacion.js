$(document).ready(function(){
    $("#modelos").click(function(){
        $("img3D").hide();
    });
    $("#modelos2").click(function(){
        $("img3D").show();
    });
});